package uts.c14220282.c14220282_tugas

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [home.newInstance] factory method to
 * create an instance of this fragment.
 */
class home : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }


    private val numbers = (1..5).flatMap { listOf(it, it) }.shuffled()
    private var firstSelected: Button? = null
    private var secondSelected: Button? = null
    private var currScore = 50
    private val numbersGame = mutableListOf<Int>()
    val input = view?.findViewById<EditText>(R.id.editTextInput)



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        val receivedBundle = arguments
        val inputNum = receivedBundle?.getString("DATA")?.toInt()
        val scores = view.findViewById<TextView>(R.id.scoreText)
        val giveUp = view.findViewById<Button>(R.id.buttonGiveUp)


        val allButtons = listOf(
            view.findViewById<Button>(R.id.button1),
            view.findViewById<Button>(R.id.button2),
            view.findViewById<Button>(R.id.button3),
            view.findViewById<Button>(R.id.button4),
            view.findViewById<Button>(R.id.button5),
            view.findViewById<Button>(R.id.button6),
            view.findViewById<Button>(R.id.button7),
            view.findViewById<Button>(R.id.button8),
            view.findViewById<Button>(R.id.button9),
            view.findViewById<Button>(R.id.button10)
        )

        giveUp.setOnClickListener {
            val mBundle = Bundle()
            mBundle.putString("DATA", scores.text.toString())

            val result = score()
            result.arguments = mBundle

            parentFragmentManager.beginTransaction().apply {
                replace(R.id.main, result, result::class.java.simpleName)
                addToBackStack(null)
                commit()
            }
        }




        if (inputNum != null) {
            val gameNumbers = numbers

            for (i in allButtons.indices) {
                allButtons[i].text = "?"
                allButtons[i].tag = gameNumbers[i]

                allButtons[i].setOnClickListener {
                    onClicked(allButtons[i], scores)
                }
            }
          }
        }

    private fun onClicked(button: Button, points: TextView) {
        button.text = button.tag.toString()


        if (firstSelected == null) {
            firstSelected = button
        } else if (secondSelected == null && button != firstSelected) {
            secondSelected = button

            if (firstSelected?.tag == secondSelected?.tag) {
                nowScore(points, 10)
                firstSelected?.isClickable = false
                secondSelected?.isClickable = false
                firstSelected = null
                secondSelected = null


            } else {
                Handler(Looper.getMainLooper()).postDelayed({

                    nowScore(points, -5)
                    firstSelected?.text = "?"
                    secondSelected?.text = "?"
                    secondSelected = null
                    firstSelected = null

                }, 500)
            }
        }
    }


    private fun nowScore(scoreTextView: TextView, points: Int) {
        val currScore = scoreTextView.text.toString().toInt()
        val newScore = currScore + points

        scoreTextView.text = newScore.toString()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment home.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            home().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}