package uts.c14220282.c14220282_tugas

import android.content.Context
import android.os.Bundle
import android.util.AttributeSet
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val defaultFragment = home()
        val fragmentManager = supportFragmentManager
        val menujuHome = findViewById<Button>(R.id.buttonHome)
        val menujuScore = findViewById<Button>(R.id.buttonScore)
        val menujuInput = findViewById<Button>(R.id.buttonItem)



        fragmentManager.beginTransaction()
            .add(R.id.main, defaultFragment, home::class.java.simpleName)
            .commit()


        menujuHome.setOnClickListener {
            val fragmentHome = home()
            fragmentManager.beginTransaction()
                .replace(R.id.main, fragmentHome, home::class.java.simpleName)
                .commit()
        }

        menujuScore.setOnClickListener {
            val fragmentScore = score()
            fragmentManager.beginTransaction()
                .replace(R.id.main, fragmentScore, score::class.java.simpleName)
                .commit()
        }

        menujuInput.setOnClickListener {
            val fragmentInput = input()
            fragmentManager.beginTransaction()
                .replace(R.id.main, fragmentInput, input::class.java.simpleName)
                .commit()
        }

    }
}